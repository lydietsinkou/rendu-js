let person = {
    name: 'john',
    cool: 10,
}

const musics =[
    "wejdene - Anissa",
    "keenv - Rien qu'une fois",
    "M. Pokora - A nos actes manqués",
    "Lartiste - Mon pays",
]

let trajet = {
    change: 0,
    radio: musics[0],
    redlights: 30,
    poinnts: 40,
}

let taketaxinumber = 1
let x =0

function taketaxi(person, trajet, taketaxinumber){
    while(trajet.redlights > 0) {

    }
  }

  for (trajet.poinnts == 1){
    alert("depart") 
  }
  while (trajet.poinnts < 40) {
    trajet = poinnts ++
  }
  
for musics[] == anissa ;
    person.cool--
    taketaxinumber ++ ;
    

    alert ("la musics en cours est" musics,"et il reste taketaxinumber", taketaxinumber){

    }


for (person.cool < 0){
    alert("explosion")
}



